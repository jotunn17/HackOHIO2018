
public class Longblade extends Weapons {
	public Longblade()
	{
		super(100,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 5 + 8);
		return damage;
	}
}
