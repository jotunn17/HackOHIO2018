
public class OldStick extends Weapons {
	public OldStick()
	{
		super(1,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 2 + 1);
		return damage;
	}
}
