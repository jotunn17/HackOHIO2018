
public class SpikedClub extends Weapons {
	public SpikedClub()
	{
		super(10,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 3 + 2);
		return damage;
	}
}
