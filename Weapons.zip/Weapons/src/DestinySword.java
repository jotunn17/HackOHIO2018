
public class DestinySword extends Weapons {
	public DestinySword()
	{
		super(180,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 6 + 14);
		return damage;
	}
}
