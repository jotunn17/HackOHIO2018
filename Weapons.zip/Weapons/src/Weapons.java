
public class Weapons {
	int price, attackPoints;
	public Weapons(int price, int attackPoints)
	{
		this.price = price;
		this.attackPoints = attackPoints;
	}
	public void getAttackPoints()
	{
		this.attackPoints = attackPoints;
		System.out.print(this.attackPoints);
	}
	public void getPrice()
	{
		this.price = price;
		System.out.print(this.price);
	}
}
