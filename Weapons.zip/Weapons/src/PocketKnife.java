
public class PocketKnife extends Weapons {
	public PocketKnife()
	{
		super(25,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 4 + 3);
		return damage;
	}
}
