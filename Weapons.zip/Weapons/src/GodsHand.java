
public class GodsHand extends Weapons {
	public GodsHand()
	{
		super(350,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 11 + 21);
		return damage;
	}
}
