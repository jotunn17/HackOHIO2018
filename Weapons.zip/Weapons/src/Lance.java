
public class Lance extends Weapons {
	public Lance()
	{
		super(60,generateDamage());
	}
	public static int generateDamage()
	{
		int damage = (int)(Math.random() * 5 + 4);
		return damage;
	}
}
