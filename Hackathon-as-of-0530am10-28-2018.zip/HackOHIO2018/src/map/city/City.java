package map.city;

import java.util.Scanner;

import item.Item;
import item.armor.*;
import item.weapons.*;
import map.landmarks.Landmark;
import npc.Inventory;
import npc.Player;

public class City implements Landmark {
	
	private String name;
	final private String[] LOCALE = {"inn", "shop"};
	private Inventory shopInventory;
	private int population;
	
	@Override
	public String label() {
		return "city";
	}

	@Override
	public String name() {
		return name;
	}

	public String[] locations() {
		return LOCALE;
	}

	@Override
	public char icon() {
		// TODO Auto-generated method stub
		return 'C';
	}
	
	public City() {
		
		population = (int)(Math.random() * 400) + 200;
		shopInventory = getShopInventory();
		
	}
	public void printStats() {
		System.out.println("You are in the city of " + name + ".");
		System.out.println("Population: " + population);
		
	}
	@Override
	public boolean canLeave() {
		// TODO Auto-generated method stub
		return true;
	}


	public void shopMenu()
	{
		System.out.println("Welcome to the shop!");
		System.out.println("The items are:");
		for(int i = 0; i<shopInventory.numOfItems();i++)
		{
			System.out.println(i + ") " + shopInventory.getItem(i).getName() + " Price: " + shopInventory.getItem(i).getPrice());
		}
	}
	public Inventory getShopInventory()
	{
		Inventory shopInventory = new Inventory();
		Armor[] armors = {(Armor) new Chainmail(), (Armor) new NoviceRobe(), (Armor) new PeasantsCloth(), 
				(Armor) new PhoenixTunic(), (Armor) new PlateArmor(), (Armor) new VulcansGear()};
		Weapons[] weapons = {(Weapons) new DestinySword(), (Weapons) new GodsHand(), (Weapons) new Lance(), (Weapons) new Longblade(), (Weapons) new OldStick(), (Weapons) new PocketKnife(), (Weapons) new SpikedClub()};
		int rand =  (int)(Math.random() * armors.length);
		int rand2 =  (int)(Math.random() * weapons.length);
		shopInventory.increaseInventory(armors[rand]);
		shopInventory.increaseInventory(weapons[rand2]);
		return shopInventory;
	}
	
	private int getChoice(Scanner in) {
		int choice;
		System.out.println("Enter action:");
		System.out.println("0: [V]isit shop");
		System.out.println("1: [L]eave");
		System.out.print(">>");
		String input = in.nextLine();
		if (input.equals("0") || input.equalsIgnoreCase("v") || input.equalsIgnoreCase("visit")) {
			choice = 0;
		} else if (input.equals("1") || input.equalsIgnoreCase("l") || input.equalsIgnoreCase("leave")) {
			choice = 1;
		} else {
			System.out.println("Sorry, input not recognized.");
			choice = getChoice(in);
		}
		return choice;
	}
	
	private int getShopAction(Scanner in) {
		int choice;
		System.out.println("Enter action:");
		System.out.println("0: [B]uy item");
		System.out.println("1: [L]eave");
		System.out.print(">>");
		String input = in.nextLine();
		if (input.equals("0") || input.equalsIgnoreCase("b") || input.equalsIgnoreCase("buy")) {
			choice = 0;
		} else if (input.equals("0") || input.equalsIgnoreCase("l") || input.equalsIgnoreCase("leave")) {
			choice = 1;
		} else {
			System.out.println("Sorry, input not recognized.");
			choice = getShopAction(in);
		}
		return choice;
	}

	@Override
	public void dialogue(Player player) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int choice = getChoice(in);
		while (choice != 1) {
			shopMenu();
			System.out.println();
			System.out.println("You have " + player.getNetWorth() + " gold.");
			
			int shopAction = getShopAction(in);
			System.out.println();
			if (shopAction == 0) {
				int index = in.nextInt(2);
				Item item = shopInventory.getItem(index);
				player.buyItem(item);
			}
			choice = getChoice(in);
		}
	}
	
	/*
	 * TODO: Finish City
	 */
}