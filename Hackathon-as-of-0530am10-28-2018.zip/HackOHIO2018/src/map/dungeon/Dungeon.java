package map.dungeon;
import map.landmarks.Landmark;
import npc.Player;

public class Dungeon implements Landmark {
	private String name;
	private Room[] rooms;
	private int currentRoom;
	private int length;
	
	public Dungeon() {
		rooms = new Room[(int)(Math.random() * 7 + 1)];
		length = rooms.length;
		currentRoom = 0;
	}

	@Override
	public String label() {
		return "dungeon";
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public char icon() {
		return 'D';
	}
	
	public int length() {
		return length;
	}
	
	public void advance() {
		if (rooms[currentRoom].canLeave() && currentRoom < length - 1) {
			currentRoom++;
			System.out.println("You advance further into the dungeon...");
		} else if (currentRoom == length) {
			System.out.println("You have reached the end of the dungeon.");
		} else {
			System.out.println("You cannot leave just yet.");
		}
	}
	
	public boolean retreat() {
		boolean leave = false;
		if (rooms[currentRoom].canLeave() && currentRoom != 0) {
			currentRoom--;
			System.out.println("You advance further into the dungeon...");
		} else if (currentRoom == 0) {
			System.out.println("You leave the dungeon...");
			leave = true;
		} else {
			System.out.println("You cannot leave just yet.");
		}
		return leave;
	}

	@Override
	public boolean canLeave() {
		return rooms[currentRoom].canLeave();
	}
	
	@Override
	public void dialogue(Player player) {
		
	}
	
	
}
