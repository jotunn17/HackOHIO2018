package map.landmarks;

import npc.NPC;
import npc.Player;
import npc.creatures.CorruptedGnome;
import npc.creatures.DwarfClass;
import npc.creatures.ElfClass;
import npc.creatures.FireImp;

public class Bridge implements Landmark {
	
	private NPC guard;
	
	@Override
	public String label() {
		return "bridge";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "A bridge over a babbling brook.";
	}

	@Override
	public char icon() {
		// TODO Auto-generated method stub
		return 'X';
	}

	@Override
	public boolean canLeave() {
		// TODO Auto-generated method stub
		boolean canLeave = false;
		if (guard.getHealth() == 0) {
			canLeave = true;
		}
		return canLeave;
	}
	
	public Bridge() {
		int rand = (int)(Math.random() * 5);
		if (rand == 0) {
			guard = new DwarfClass();
		} else if (rand == 1) {
			guard = new ElfClass();
		} else if (rand == 2) {
			guard = new CorruptedGnome();
		} else {
			guard = new FireImp();
		}
	}

	@Override
	public void dialogue(Player player) {
		// TODO Auto-generated method stub
		System.out.println("There is a " + guard.type() + " blocking your path.");
		player.doBattle(this.guard);
	}

}
