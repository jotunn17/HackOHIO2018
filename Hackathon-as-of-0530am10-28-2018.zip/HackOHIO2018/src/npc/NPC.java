package npc;

public interface NPC {

    public void greet();

    public void attack();

    public void takeDamage(int d);
    
    /**
     * Return the health of the NPC
     */
    public int getHealth();
    
    public int getDefense();
    
    public int getAttack();
    
    /**
     * Return the type of NPC
     */
    public String type();
    
    public static void battle() {
    	
    }

}
