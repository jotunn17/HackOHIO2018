package npc;
import java.util.*;


import item.Item;
import item.armor.Armor;
import item.armor.PeasantsCloth;
import item.weapons.OldStick;
import item.weapons.Weapons;
public class Player {

	private Stats stats;
	private Inventory inv;
	
	public Player() {
		stats= new Stats(100, 1, 1, 50);
		inv = new Inventory();
		Item stick = new OldStick();
		Item armor = new PeasantsCloth();
		inv.increaseInventory(stick);
		inv.increaseInventory(armor);
		}
	
	public Weapons equipWeapon()
	{
		Weapons[] weapons = displayWeapons();
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Pick your weapon (select a number) ");
		int weaponNumber = keyboard.nextInt();
		keyboard.nextLine();
		Weapons weapon = weapons[weaponNumber];
//		keyboard.close();
		return weapon;
	}
	
	public Armor equipArmor()
	{
		Armor[] armors = displayArmor();
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Pick your armor (select a number)");
		int armorNumber = keyboard.nextInt();
		keyboard.nextLine();
		Armor armor = armors[armorNumber];
//		keyboard.close();
		return armor;
	}
	
	public Weapons[] displayWeapons()
	{
		int count = 0;
		for(int i = 0;i<inv.numOfItems();i++)
		{
			if(inv.getItem(i).isWeapon())
			{
				System.out.println(count + ") " + inv.getItem(i).getName());

				count++;
			}
		}
		Weapons[] weapons = new Weapons[count];
		for(int i = 0, index = 0;i<inv.numOfItems();i++)
		{
			if(inv.getItem(i).isWeapon())
			{
				weapons[index] = (Weapons) inv.getItem(i);
				index++;
			}
			
		}
		return weapons;
		
		
	}
	
	public Armor[] displayArmor()
	{
		int count = 0;
		for(int i = 0;i<inv.numOfItems();i++)
		{
//			System.out.println(inv.getItem(i).isArmor());
			if(inv.getItem(i).isArmor())
			{
				System.out.println(count + ") " + inv.getItem(i).getName());
				count++;
			}
		}
//		System.out.println(count);
		Armor[] armor = new Armor[count];
		for(int i = 0, index = 0;i<inv.numOfItems();i++)
		{
//			System.out.println(inv.getItem(i).getName());
			if(inv.getItem(i).isArmor())
			{
				armor[index] = (Armor) inv.getItem(i);
				index++;
			}
		}
		return armor;
		
	}
	private void attack(NPC enemy) {
		int attackDealt = (stats.getAttack() - (int)0.25*enemy.getHealth());
		System.out.println("You dealt " + attackDealt + " damage");
	}
	
	public void takeDamage(int enemyAtk) {
		int damageTaken = enemyAtk - (int)0.2*stats.getDefense();
		stats.decreaseHealth(damageTaken);
		System.out.println("You took " + damageTaken + " damage");
	}
	
	private int promptChoice(Scanner in) {
		int choice;
		System.out.println("Enter action:");
		System.out.println("0: [A]ttack");
		System.out.println("1: [U]se health potion");
		System.out.println("2: [F]lee");
		System.out.print(">>");
		String input = in.nextLine();
		if (input.equals("0") || input.equalsIgnoreCase("a") 
				|| input.equalsIgnoreCase("attack")) {
			choice = 0;
		} else if (input.equals("1") || input.equalsIgnoreCase("u") 
				|| input.equalsIgnoreCase("use")) {
			choice = 1;
		} else if (input.equals("2") || input.equalsIgnoreCase("f") 
				|| input.equalsIgnoreCase("flee")) {
			choice = 2;
		} else {
			System.out.println("Sorry, imput was not recognized.");
			choice = promptChoice(in);
		}
		return choice;
	}
	
	public void doBattle(NPC enemy) {
		int potions = 3;
		int enemyMaxHP = enemy.getHealth();
		Weapons weapon = equipWeapon();
		Armor armor = equipArmor();
		Scanner keyboard = new Scanner(System.in);
		while (enemy.getHealth() > 0 && stats.getHealth() > 0) {
			System.out.println(enemy.type() + ":");
			printHeader(enemy, potions);
			enemy.greet();
			int action = promptChoice(keyboard);
			if (action == 0) {
				int damage = (stats.getAttack() + weapon.getAttackPoints()) * (100 - enemy.getDefense()) / 100;
				enemy.takeDamage(damage);
				System.out.println("You dealt " + damage + " to the " + enemy.type());
			} else if (action == 1) {
				potions = usePotion(potions);
			} else if (action == 2) {
				enemy.takeDamage(enemy.getHealth());
			}
			enemy.greet();
			action = (int)(Math.random() * 3);
			
			if (action == 0) {
				int damage = (enemy.getAttack() * (100 - stats.getDefense())) / 100;
				takeDamage(damage);
				System.out.println(enemy.type() + " dealt you " + damage + " damage!");
			} else if (action == 1) {
				int heal = (int)(Math.random() * -15);
				enemy.takeDamage(heal);
				if (enemy.getHealth() > enemyMaxHP) {
					enemy.takeDamage(enemy.getHealth() - enemyMaxHP);
				}
				System.out.println(enemy.type() + "healed for " + heal*-1);
			} else if (action == 2) {
				int flee = (int)(Math.random() * 100);
				if (flee == 1) {
					System.out.println(enemy.type() + " fled");
					enemy.takeDamage(enemy.getHealth());
				}
				System.out.println(enemy.type() + " did nothing!");
			}
		}
		inv.increaseGold((int)(Math.random() * 20) + 5);
	}
	
	private int usePotion(int potions) {
		if (potions == 0) {
			System.out.println("You are out of potions!");
		} else if (stats.getHealth() + 25 > 100){
			stats.setHealth(100);
			potions--;
			System.out.println("You healed to full! (100HP)");
		} else {
			potions--;
			stats.increaseHealth(25);
			System.out.println("You heal for 25 points!");
		}
		return potions;
	}
	
	public void buyItem(Item item) {
		int price = item.getPrice();
		if (price <= inv.viewGold()) {
			inv.increaseInventory(item);
			inv.decreaseGold(price);
			System.out.println("You bought " + item.getName());
			inv.viewGold();
		} else {
			System.out.println("You don't have enough gold!");
		}
		
	}
	
	private void printHeader(NPC enemy, int potions) {
		System.out.println(enemy.type());
		System.out.println(enemy.getHealth());
		System.out.println();
		System.out.println("You:");
		System.out.println(stats.getHealth());
		System.out.println("Potions: " + potions);
	}
	
	public int getNetWorth() {
		return inv.viewGold();
	}
	
	public int getHealth() {
		return stats.getHealth();
	}
	
}
