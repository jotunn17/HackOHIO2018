package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class FireImp implements NPC {
    Stats FireImpStats;
    int gold;

    public FireImp() {

        Random rng = new Random();
        //health, attack, defense, dexterity
        this.FireImpStats = new Stats(5, rng.nextInt(6) + 1, 1, 100);
        this.gold = rng.nextInt(2) + 1;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("WEEEHEEEHEEE");
        } else if (decideGreet < 2) {
            System.out.println("*spits fire*");
        } else {
            System.out.println("Me NOT happy...");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.FireImpStats.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return FireImpStats.getHealth();
	}
	
	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "fire imp";
	}
	
	@Override
	public int getDefense() {
		// TODO Auto-generated method stub
		return FireImpStats.getDefense();
	}
	
	@Override
	public int getAttack() {
		return FireImpStats.getAttack();
	}

}
