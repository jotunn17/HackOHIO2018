package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class DiamondColossus implements NPC {
    Stats DiamondColossus;
    int gold;

    public DiamondColossus() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.DiamondColossus = new Stats(75, rng.nextInt(32) + 27, 1, 100);
        this.gold = rng.nextInt(32) + 27;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("TIME TO PERISH.");
        } else if (decideGreet < 2) {
            System.out.println("ANNIHILATION IS IMMINENT.");
        } else {
            System.out.println("I WILL CRUSH YOU.");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.DiamondColossus.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		return DiamondColossus.getHealth();
	}

	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "diamond colossus";
	}
	
	@Override
	public int getDefense() {
		// TODO Auto-generated method stub
		return DiamondColossus.getDefense();
	}
	
	@Override
	public int getAttack() {
		return DiamondColossus.getAttack();
	}

}
