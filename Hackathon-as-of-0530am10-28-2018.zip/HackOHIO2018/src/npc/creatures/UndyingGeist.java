package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class UndyingGeist implements NPC {
    Stats UndyingGeist;
    int gold;

    public UndyingGeist() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.UndyingGeist = new Stats(9, rng.nextInt(5) + 3, 1, 100);
        this.gold = rng.nextInt(5) + 3;
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.UndyingGeist.decreaseHealth(d);
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out
                    .println("Time to enact my revenge on this filthy nomad!");
        } else if (decideGreet < 2) {
            System.out.println("Care to join me?");
        } else {
            System.out.println("Trick or treat, traveler...");
        }
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return UndyingGeist.getHealth();
	}
	
	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "undying geist";
	}
	
	@Override
	public int getDefense() {
		// TODO Auto-generated method stub
		return UndyingGeist.getDefense();
	}
	
	@Override
	public int getAttack() {
		return UndyingGeist.getAttack();
	}

}