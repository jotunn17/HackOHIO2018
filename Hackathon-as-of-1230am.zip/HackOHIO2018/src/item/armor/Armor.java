package item.armor;

import item.Item;

public interface Armor extends Item {
	public int getDefensePoints();
}
