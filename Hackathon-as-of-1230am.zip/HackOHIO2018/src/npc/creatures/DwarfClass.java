package npc.creatures;

import npc.Humanoid;
import npc.Inventory;
import npc.Stats;

public class DwarfClass implements Humanoid {
    private Stats dwarfStats;
    private Inventory inv;

    public DwarfClass() {
        //not final dwarf stats
        this.dwarfStats = new Stats(100, 20, 20, 100);
    }
    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("Dwarf greeting 1");
        } else if (decideGreet < 2) {
            System.out.println("Dwarf greeting 2");
        } else {
            System.out.println("Dwarf greeting 3");
        }
    }
    @Override
    public void attack() {
        //needs filled out
    }
    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.dwarfStats.decreaseHealth(d);
    }

	@Override
	public Inventory getInventory() {
		// TODO Auto-generated method stub
		return inv;
	}
	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return dwarfStats.getHealth();
	}
	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "dwarf";
	}
}
