package map.landmarks;

public class Empty implements Landmark {

	@Override
	public String label() {
		// TODO Auto-generated method stub
		return "empty field";
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "field";
	}

	@Override
	public char icon() {
		// TODO Auto-generated method stub
		return '_';
	}

	@Override
	public boolean canLeave() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void dialogue() {
		// TODO Auto-generated method stub
		System.out.println("There doesn't seem to be anything to do here...");
	}

}
