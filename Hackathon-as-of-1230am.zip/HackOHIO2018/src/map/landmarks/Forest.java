package map.landmarks;

import java.util.Scanner;

public class Forest implements Landmark {
	
	private String name;
	
	@Override
	public String label() {
		return "forest";
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public char icon() {
		return 'F';
	}
	
	public Forest() {
		
	}

	@Override
	public boolean canLeave() {
		return true;
	}

	@Override
	public void dialogue() {
		// TODO Auto-generated method stub
		System.out.println("This forest seems peaceful...");
		Scanner in = new Scanner(System.in);
		int action = getAction(in);
		if (action == 0) {
			System.out.println("Waiting and relaxing...");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
			}
			System.out.println("You awake refreshed.");
		}
		
		
	}
		
	private static int getAction(Scanner in) {
		int action;
		System.out.println();
		System.out.println("Enter an action: ");
		System.out.println("0: [W]ait here for some time");
		System.out.println("1: [L]eave");
		String input = in.nextLine();
		if (input.equals("0") || input.equalsIgnoreCase("W") || input.equalsIgnoreCase("wait")) {
			action = 0;
		} else if (input.equals("1") || input.equalsIgnoreCase("l") || input.equalsIgnoreCase("leave")) {
			action = 1;
		} else {
			System.out.println("Sorry, that input is not recognized.");
			action = getAction(in);
		}
		return action;
	}

}
