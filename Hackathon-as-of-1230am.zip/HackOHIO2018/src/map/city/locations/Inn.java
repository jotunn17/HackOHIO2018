package map.city.locations;

import npc.NPC;

public class Inn implements Location {
	
	final private String type = "inn";
	private String[] description;
	private int availableRooms;
	private int rooms;
	
	@Override
	public String type() {
		return type;
	}

	@Override
	public String []getDescription() {
		return description;
	}

	public boolean canRent() {
		boolean canRent = true;
		if (availableRooms == 0) {
			canRent = false;
		}
		return canRent;
	}
	
	public Inn() {
		
		// Rooms
		this.rooms = (int)(Math.random() * 6) + 1;
		// Rooms available = rooms - inhabitants
		this.availableRooms = rooms - (int)(Math.random() * this.rooms + 0.5);
		description = new String[2];
		description[0] = "You are in the inn."; 
		description[1] = "Rooms available: " + availableRooms + "/" + rooms;		
	}
	
	

}
