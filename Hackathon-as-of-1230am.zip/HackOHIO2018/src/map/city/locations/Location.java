package map.city.locations;

public interface Location {
	
	/**
	 * Returns the type of location
	 */
	public String type();
	
	/**
	 * Returns the description of the location
	 * and type
	 */
	public String[] getDescription();
	
	/**
	 * Prints the description
	 */
	public default void printDescription() {
		String[] desc = getDescription();
		for (int i = 0 ; i < desc.length ; i++) {
			System.out.println(desc[i]);
		}
	}
}
