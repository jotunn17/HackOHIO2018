package map.city;

import map.city.locations.Inn;
import map.city.locations.Location;
import map.city.locations.Shop;
import map.landmarks.Landmark;

public class City implements Landmark {
	
	private String name;
	final private String[] LOCALE = {"inn", "shop"};
	private Location inn;
	private Location shop;
	private int population;
	
	@Override
	public String label() {
		return "city";
	}

	@Override
	public String name() {
		return name;
	}

	public String[] locations() {
		return LOCALE;
	}

	@Override
	public char icon() {
		// TODO Auto-generated method stub
		return 'C';
	}
	
	public City() {
		
		population = (int)(Math.random() * 400) + 200;
		inn = new Inn();
		shop = new Shop();
		
	}
	
	public Location enterInn() {
		return inn;
	}
	
	public Location enterShop() {
		return shop;
	}
	
	public void printStats() {
		System.out.println("You are in the city of " + name + ".");
		System.out.println("Population: " + population);
		
	}

	@Override
	public boolean canLeave() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void dialogue() {
		// TODO Auto-generated method stub
		
	}
	
	/*
	 * TODO: Finish City
	 */
}
