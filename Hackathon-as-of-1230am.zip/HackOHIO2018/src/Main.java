import map.*;
import map.landmarks.Landmark;

import java.util.Scanner;

import item.*;
import npc.*;

public class Main {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Map map = new Map(10, 10);
		
		while (true) {
			map.print();
			System.out.println();
			map.printKey();
			int action = mapAction(in);
			if (action == 0) {
				map.promptForMove(in);
				printWhiteSpace(15);
			} else if (action == 1) {
				printWhiteSpace(15);
				Landmark loc = map.enterLandmark();
				System.out.println("You enter the " + loc.label());
				loc.dialogue();
			} else if (action == 2) {
				printWhiteSpace(15);
				System.out.println("You look around to see you are near a(n) " + map.enterLandmark().label() + ".");
			}
			System.out.println();
		}
	}
	
	public static int mapAction(Scanner in) {
		int action;
		System.out.println();
		System.out.println("Enter an action: ");
		System.out.println("0: [M]ove on the map");
		System.out.println("1: [E]nter the current location");
		System.out.println("2: [O]bserve the surrounding area");
		System.out.print(">>");
		String input = in.nextLine();
		
		if (input.equals("0") || input.equalsIgnoreCase("M") || input.equalsIgnoreCase("Move")) {
			action = 0;
		} else if (input.equals("1") || input.equalsIgnoreCase("E") || input.equalsIgnoreCase("Enter")) {
			action = 1;
		} else if (input.equals("2") || input.equalsIgnoreCase("O") || input.equalsIgnoreCase("observe")) {
			action = 2;
		} else {
			System.out.println("Sorry, that action is not recognized.");
			action = mapAction(in);
		}
		
		return action;
	}
	
	public static void printWhiteSpace(int lines) {
		for (int i = 0 ; i < lines ; i++) {
			System.out.println();
		}
	}
}
