import java.util.*;

import item.armor.Armor;
import item.armor.PeasantsCloth;
import item.weapons.OldStick;
import item.weapons.Weapons;
import npc.Inventory;
import npc.Stats;
public class Player {

	private Stats stats;
	private Inventory inv;
	private Weapons weapon;
	private Armor armor;
	
	public Player() {
		stats= new Stats(100, 1, 1, 50);
		inv = new Inventory();
		weapon = new OldStick();
		armor = new PeasantsCloth();
		}
	
	public Weapons equipWeapon()
	{
			displayWeapons();
			Scanner keyboard = new Scanner(System.in);
			System.out.print("Pick your weapon (select a number) ");
			int weaponNumber = keyboard.nextInt();
			Weapons weapon = (Weapons) inv.getItem(weaponNumber);
			return weapon;
	}
	
	public Item equipArmor()
	{
			displayWeapons();
			Scanner keyboard = new Scanner(System.in);
			System.out.print("Pick your armor (select a number)");
			int armorNumber = keyboard.nextInt();
			Item armor = inv.getItem(armorNumber);
			return armor;
	}
	
	public void displayWeapons()
	{
		int count = 0;
		for(int i = 0;i<inv.numOfItems();i++)
		{
			if(inv.getItem(i).isWeapon()==true)
			{
				System.out.print(count + ") " +inv.getItem(i).getName());
			}
		}
		
	}
	
	public void displayArmor()
	{
		int count = 0;
		for(int i = 0;i<inv.numOfItems();i++)
		{
			if(inv.getItem(i).isArmor()==true)
			{
				System.out.print(count + ") " +inv.getItem(i).getName());
			}
		}
		
	}
	public void attack(NPC enemy) {
		int attackDealt = (stats.attack - (int)0.25*enemy.getHealth());
		System.out.println("You dealt " + attackDealt + " damage");
	}
	
	public void takeDamage(int enemyAtk) {
		int damageTaken = enemyAtk - (int)0.2*stats.defense;
		System.out.println("You took " + damageTaken + " damage");
	}
	
	public void buyItem(Item item) {
		
	}
	
}
