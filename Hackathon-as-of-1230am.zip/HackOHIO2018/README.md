# This RPG was made for HackOHIO2018
### Contributors:
*Atharva Doshi*
*Joe Jerig*
*Mitch Margonti*
*Daniel Zhong*

### No license or external library was used in the creation of this game.
### _**All elements are from our original ideas.**_