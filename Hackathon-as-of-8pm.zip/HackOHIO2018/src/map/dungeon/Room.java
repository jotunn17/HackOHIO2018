package map.dungeon;

import npc.NPC;
import npc.creatures.*;

public class Room {
	private Container[] containers;
	private NPC[] enemies;
	
	public Room() {
		containers = new Container[(int)(Math.random() * 2) + 1];
		for (int i = 0 ; i < containers.length; i++) {
			containers[i] = new Container();
		}
		enemies = new NPC[(int)(Math.random() * 3)];
		for (int i = 0 ; i < enemies.length ; i++) {
			int rand = (int)(Math.random() * 15);
			if (rand == 0) {
				enemies[i] = new BrainEatingLich();
			} else if (rand == 1) {
				enemies[i] = new CorruptedGnome();
			} else if (rand == 2) {
				enemies[i] = new DiamondColossus();
			} else if (rand == 3) {
				enemies[i] = new DiseasedDingo();
			} else if (rand == 4) {
				enemies[i] = new RavenousWyvern();
			} else if (rand == 5) {
				enemies[i] = new UndyingGeist();
			} else if (rand == 6) {
				enemies[i] = new VenomousSerpent();
			} else if (rand == 7) {
				enemies[i] = new ViciousSpider();
			} else if (rand == 8) {
				enemies[i] = new WickedSorceress();
			} else {
				enemies[i] = new FireImp();
			}
		}
	}
	
	public boolean canLeave() {
		boolean allDead = true;
		for (int i = 0; i < enemies.length ; i++) {
			if (enemies[i].getHealth() != 0) {
				allDead = false;
			}
		}
		return allDead;
	}
}
