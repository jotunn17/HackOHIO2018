package map;

import java.util.Scanner;

import map.city.City;
import map.landmarks.Forest;
import map.landmarks.Landmark;

public class Map {

	private String name;
	private Landmark[][] layout;
	private int[] playerCoords;
	
	public Map(int width, int height) {
		// TODO: FIX THIS
		name = "placeholder";
		playerCoords = new int[2];
		playerCoords[0] = 0;
		playerCoords[1] = 0;
		layout = new Landmark[height][width];
		// TODO: FIX THIS
		for (int i = 0 ; i < layout.length; i++) {
			for (int j = 0 ; j < layout[i].length; j++) {
				int random = (int)(Math.random() * 1);
				if (random == 0) { 
					layout[i][j] = new City();
				}
				
			}
			
		}
		
	}
	
	public void print() {
		for (int i = 0 ; i < layout.length; i++) {
			for (int j = 0 ; j < layout[i].length; j++) {
				if (playerCoords[0] == j && playerCoords[1] == i) {
					System.out.print("[@]");
				} else {
					System.out.print("[" + layout[i][j].icon() + "]");	
				}
			}
			System.out.println();
		}
	}
	
	public String name() {
		return name;
	}
	
	public void promptForMove(Scanner in) {
		System.out.println("Which direction?");
		System.out.println(" 0: North");
		System.out.println(" 1: East");
		System.out.println(" 2: South");
		System.out.println(" 3: West");
		System.out.print(">>");
		String dir = in.nextLine();
		if ((dir.equals("0") || dir.equalsIgnoreCase("n") || dir.equalsIgnoreCase("north")) && playerCoords[1] > 0) {
			playerCoords[1]--;
		} else if ((dir.equals("1") || dir.equalsIgnoreCase("e") || dir.equalsIgnoreCase("east")) && playerCoords[0] < layout.length) {
			playerCoords[0]++;
		} else if ((dir.equals("2") || dir.equalsIgnoreCase("s") || dir.equalsIgnoreCase("south")) && playerCoords[1] < layout[playerCoords[0]].length) {
			playerCoords[1]++;
		} else if ((dir.equals("3") || dir.equalsIgnoreCase("w") || dir.equalsIgnoreCase("west")) && playerCoords[0] > 0) {
			playerCoords[0]--;
		} else {
			System.out.println("Sorry, that is not a valid input.");
			promptForMove(in);
		}
	}
	
	public Landmark enterLandmark() {
		return layout[playerCoords[1]][playerCoords[0]];
	}
	
	public static void main(String[] args) {
		Map map = new Map(20,20);
		Scanner in = new Scanner(System.in);
		while (true) {
			map.print();
			map.promptForMove(in);			
		}
	}
	
}
