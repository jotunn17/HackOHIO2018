package item.armor;
public class PeasantsCloth implements Armor{
	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getWeight() {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public int getDefensePoints() {
		// TODO Auto-generated method stub
		
		return 1;
	}
}
