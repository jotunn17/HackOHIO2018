package item.weapons;
public class Longblade implements Weapons {


	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 100;
	}

	@Override
	public int getWeight() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public int getAttackPoints() {
		// TODO Auto-generated method stub
		int damage = (int)(Math.random() * 5 + 8);
		return damage;
	}
}

