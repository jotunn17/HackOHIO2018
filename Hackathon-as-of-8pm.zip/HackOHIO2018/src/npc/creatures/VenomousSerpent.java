package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class VenomousSerpent implements NPC {
    Stats VenomousSerpent;
    int gold;

    public VenomousSerpent() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.VenomousSerpent = new Stats(20, rng.nextInt(9) + 6, 1, 100);
        this.gold = rng.nextInt(8) + 6;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("*LOUD HISSING NOISE*");
        } else if (decideGreet < 2) {
            System.out.println("*PURPLE GOO SECRETES FROM MOUTH*");
        } else {
            System.out.println("*BARES FANGS*");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.VenomousSerpent.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return VenomousSerpent.getHealth();
	}

}
