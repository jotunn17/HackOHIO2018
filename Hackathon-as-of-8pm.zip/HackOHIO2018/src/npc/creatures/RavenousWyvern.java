package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class RavenousWyvern implements NPC {
    Stats RavenousWyvern;
    int gold;

    public RavenousWyvern() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.RavenousWyvern = new Stats(65, rng.nextInt(18) + 13, 1, 100);
        this.gold = rng.nextInt(31) + 25;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("*BREATHES FIRE*");
        } else if (decideGreet < 2) {
            System.out.println("*BARES TEETH*");
        } else {
            System.out.println("ROOOOOAAAAAAARRRRR");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.RavenousWyvern.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return RavenousWyvern.getHealth();
	}

}
