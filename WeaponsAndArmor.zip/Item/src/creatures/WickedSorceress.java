package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class WickedSorceress implements NPC {
    Stats WickedSorceress;
    int gold;

    public WickedSorceress() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.WickedSorceress = new Stats(48, rng.nextInt(14) + 10, 1, 100);
        this.gold = rng.nextInt(18) + 13;

    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("*CONJURES FIRE*");
        } else if (decideGreet < 2) {
            System.out.println("*CONJURES ICE*");
        } else {
            System.out.println("*CONJURES ELECTRIC");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.WickedSorceress.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return WickedSorceress.getHealth();
	}

}