
package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class ViciousSpider implements NPC {
    Stats ViciousSpider;
    int gold;

    public ViciousSpider() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.ViciousSpider = new Stats(15, rng.nextInt(8) + 5, 1, 100);
        this.gold = rng.nextInt(5) + 3;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("*EYES GLOW A PIERCING RED*");
        } else if (decideGreet < 2) {
            System.out.println("*BECKONS TO WEB OF DEAD ANIMALS*");
        } else {
            System.out.println("*SHOWS TEETH*");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.ViciousSpider.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		// TODO Auto-generated method stub
		return ViciousSpider.getHealth();
	}

}