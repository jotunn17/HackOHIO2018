package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class DiseasedDingo implements NPC {
    Stats DiseasedDingo;
    int gold;

    public DiseasedDingo() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.DiseasedDingo = new Stats(40, rng.nextInt(13) + 9, 1, 100);
        this.gold = rng.nextInt(16) + 12;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("Muaheheheheh *cough* heheh...");
        } else if (decideGreet < 2) {
            System.out.println("Ahahahahaha *sneeze* haha...");
        } else {
            System.out.println("Huheuheuhe *vomits* hueuhe...");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.DiseasedDingo.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		return DiseasedDingo.getHealth();
	}

}
