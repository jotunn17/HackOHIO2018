package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class CorruptedGnome implements NPC {
    Stats CorruptedGnome;
    int gold;

    public CorruptedGnome() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.CorruptedGnome = new Stats(27, rng.nextInt(11) + 8, 1, 100);
        this.gold = rng.nextInt(10) + 7;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out
                    .println("Hidey-Ho, chump! You came to the wrong garden.");
        } else if (decideGreet < 2) {
            System.out.println("The flowers were first... now, it is you.");
        } else {
            System.out.println("I am not kind to unwelcome travelers.");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.CorruptedGnome.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		return CorruptedGnome.getHealth();
	}

}