


public interface Weapons extends Item {
	public int getAttackPoints();
}
