
public interface Armor extends Item {
	public int getDefensePoints();
}
