package npc;

import java.util.Random;

public class FireImp implements Humanoid {
    Stats FireImpStats;

    public FireImp() {

        Random rng = new Random();
        //health, attack, defense, dexterity
        this.FireImpStats = new Stats(5, rng.nextInt(3) + 1, 1, 100);
    }

    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("FireImp greeting 1");
        } else if (decideGreet < 2) {
            System.out.println("FireImp greeting 2");
        } else {
            System.out.println("FireImp greeting 3");
        }
    }

    public void attack() {
        //needs filled out
    }

    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.FireImpStats.decreaseHealth(d);
    }

}
