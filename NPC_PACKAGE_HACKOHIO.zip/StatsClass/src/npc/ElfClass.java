package npc;

public class ElfClass {
    Stats elfStats;

    public ElfClass() {
        //not final elf stats
        this.elfStats = new Stats(100, 20, 20, 100);
    }

    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("Elf greeting 1");
        } else if (decideGreet < 2) {
            System.out.println("Elf greeting 2");
        } else {
            System.out.println("Elf greeting 3");
        }
    }

    public void attack() {
        //needs filled out
    }

    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.elfStats.decreaseHealth(d);
    }

}
