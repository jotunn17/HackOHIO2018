package npc;

public class HumanClass implements Humanoid {
    Stats humanStats;

    public HumanClass() {
        //not final dwarf stats
        this.humanStats = new Stats(100, 20, 20, 100);
    }

    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("Human greeting 1");
        } else if (decideGreet < 2) {
            System.out.println("Human greeting 2");
        } else {
            System.out.println("Human greeting 3");
        }
    }

    public void attack() {
        //needs filled out
    }

    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.humanStats.decreaseHealth(d);
    }
}
