package npc;

import java.util.Random;

public class CorruptedGnome implements Humanoid {
    Stats CorruptedGnome;

    public CorruptedGnome() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.CorruptedGnome = new Stats(27, rng.nextInt(11) + 8, 1, 100);

    }

    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("CorruptedGnome greeting 1");
        } else if (decideGreet < 2) {
            System.out.println("CorruptedGnome greeting 2");
        } else {
            System.out.println("CorruptedGnome greeting 3");
        }
    }

    public void attack() {
        //needs filled out
    }

    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.CorruptedGnome.decreaseHealth(d);
    }

}