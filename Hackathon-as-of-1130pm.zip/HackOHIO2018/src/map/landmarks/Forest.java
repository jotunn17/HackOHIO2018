package map.landmarks;

public class Forest implements Landmark {
	
	private String name;
	
	@Override
	public String label() {
		return "forest";
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public char icon() {
		return 'F';
	}
	
	public Forest() {
		
	}

	@Override
	public boolean canLeave() {
		return true;
	}

}
