package map.landmarks;

public interface Landmark {
	/**
	 * Returns the label of the current landmark.
	 */
	public String label();
	
	/**
	 * Returns the name of the current landmark.
	 */
	public String name();
	
	/**
	 * Returns the icon
	 */
	public char icon();
	
	/**
	 * Returns whether the player may leave.
	 */
	public boolean canLeave();
	
	/**
	 * Runs a sort of main method specific to the instance
	 */
	public void dialogue();
	
}
