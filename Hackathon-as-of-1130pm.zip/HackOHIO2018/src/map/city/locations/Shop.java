package map.city.locations;

public class Shop implements Location {
	
	final private String type = "shop";
	
	@Override
	public String type() {
		// TODO Auto-generated method stub
		return type;
	}

	@Override
	public String[] getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

}
