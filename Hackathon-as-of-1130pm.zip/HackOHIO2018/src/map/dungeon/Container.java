package map.dungeon;

import item.Item;
import npc.Inventory;

public class Container {
	private String name;
	private int gold;
	
	public Container() {
		final String[] names = {"Barrel", "Basket", "Chest", "Urn", "Crate"};
		int i = (int)(Math.random() * 5);
		name = names[i];
		Item[] items = new Item[0];
		gold = (int)(Math.random() * 51);
	}
	
	public int takeGold() {
		int gold = this.gold;
		this.gold = 0;
		return gold;
	}
	
	public String getName() {
		return name;
	}
}
