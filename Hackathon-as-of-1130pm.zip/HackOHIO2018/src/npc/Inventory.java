package npc;

import item.Item;

public class Inventory {
	int gold;
	Item[] items = new Item[10];
	public Inventory(int gold, Item []items)
	{
		this.gold  = gold;
		this.items = items;
	}
	public void viewGold()
	{
		System.out.print("You have "+ this.gold + " gold");
	}
	public void increaseGold(int ammount)
	{
		this.gold += ammount;
	}
	public void decreaseGold(int ammount)
	{
		this.gold -= ammount;
	}
	public void viewItems(Item[] items)
	{
		System.out.print("You have ");
		for(int i = 0; i<items.length;i++)
		{
			System.out.print(items[i]+", ");
		}
	}
	public int numOfItems(Item[]items)
	{
		int count = 0;
		for(Item i: items)
		{
			if(i!=null)
			{
				count++;
			}
		}
		return count;
	}
	
	public void increaseInventory(Item[]items,Item item)
	{
		if(numOfItems(items)!=items.length)
		{
			item = items[numOfItems(items)+1];
		}
		else
		{
			System.out.print("Your inventory is full");
		}
	}
	public void decreaseInventory(Item[]items,Item item)
	{
		int loc = -1;
		for(int i = 0;i<items.length;i++)
		{
			if(items[i].equals(item))
			{
				loc = i;
				items[loc] = items[loc+1];
			}
			else
			{
				System.out.print("You don't have that item");
			}
		}
		
	}
}
