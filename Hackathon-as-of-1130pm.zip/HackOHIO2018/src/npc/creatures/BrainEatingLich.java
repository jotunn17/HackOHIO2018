package npc.creatures;

import java.util.Random;

import npc.NPC;
import npc.Stats;

public class BrainEatingLich implements NPC {
    Stats BrainEatingLich;
    int gold;

    public BrainEatingLich() {
        //health, attack, defense, dexterity
        Random rng = new Random();
        this.BrainEatingLich = new Stats(56, rng.nextInt(16) + 12, 1, 100);
        this.gold = rng.nextInt(24) + 18;
    }

    @Override
    public void greet() {
        double decideGreet = 3 * Math.random();
        if (decideGreet < 1) {
            System.out.println("Knowledge is power. And power... is tasty");
        } else if (decideGreet < 2) {
            System.out.println("DIE!");
        } else {
            System.out.println("Allow me to see that BRAIN of yours...");
        }
    }

    @Override
    public void attack() {
        //needs filled out
    }

    @Override
    public void takeDamage(int d) {
        //this is not the final algorithm for damage taken
        this.BrainEatingLich.decreaseHealth(d);
    }

	@Override
	public int getHealth() {
		return BrainEatingLich.getHealth();
	}

	@Override
	public String type() {
		// TODO Auto-generated method stub
		return "brain-eating lich";
	}

}
