package npc;

public interface Humanoid extends NPC {
	
	public Inventory getInventory();
}
