package item;

public interface Item {
	public int getPrice();
	public int getWeight();
}
