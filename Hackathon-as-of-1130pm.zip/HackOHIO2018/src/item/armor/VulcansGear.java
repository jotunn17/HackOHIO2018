package item.armor;
public class VulcansGear implements Armor{
	public int getPrice() {
		// TODO Auto-generated method stub
		return 110;
	}

	@Override
	public int getWeight() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public int getDefensePoints() {
		// TODO Auto-generated method stub
		
		return 30;
	}
}
