package item.armor;
public class NoviceRobe implements Armor{
	public int getPrice() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public int getWeight() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public int getDefensePoints() {
		// TODO Auto-generated method stub
		
		return 5;
	}
}
