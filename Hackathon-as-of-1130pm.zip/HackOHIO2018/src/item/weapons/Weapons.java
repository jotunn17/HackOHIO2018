package item.weapons;
import item.Item;

public interface Weapons extends Item {
	public int getAttackPoints();
}
