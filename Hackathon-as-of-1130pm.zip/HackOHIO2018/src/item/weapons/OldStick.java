package item.weapons;
public class OldStick implements Weapons {

	@Override
	public int getPrice() {
		return 0;
	}

	@Override
	public int getWeight() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public int getAttackPoints() {
		// TODO Auto-generated method stub
		int damage = (int)(Math.random() * 2 + 1);
		return damage;
	}
	
	
}
