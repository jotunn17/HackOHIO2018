
public class Inventory {
	int gold;
	String[] items = new String[10];
	public Inventory(int gold, String []items)
	{
		this.gold  = gold;
		this.items = items;
	}
	public void viewGold()
	{
		System.out.print("You have "+ this.gold + " gold");
	}
	public void increaseGold(int ammount)
	{
		this.gold += ammount;
	}
	public void decreaseGold(int ammount)
	{
		this.gold -= ammount;
	}
	public void viewItems(String[] items)
	{
		System.out.print("You have ");
		for(int i = 0; i<items.length;i++)
		{
			System.out.print(items[i]+", ");
		}
	}
	public int numOfItems(String[]items)
	{
		int count = 0;
		for(String i: items)
		{
			if(i!=null)
			{
				count++;
			}
		}
		return count;
	}
	
	public void increaseInventory(String[]items,String item)
	{
		if(numOfItems(items)!=items.length)
		{
			item = items[numOfItems(items)+1];
		}
		else
		{
			System.out.print("Your inventory is full");
		}
	}
	public void decreaseInventory(String[]items,String item)
	{
		int loc = -1;
		for(int i = 0;i<items.length;i++)
		{
			if(items[i].equals(item))
			{
				loc = i;
				items[loc] = items[loc+1];
			}
			else
			{
				System.out.print("You don't have that item");
			}
		}
		
	}
}
